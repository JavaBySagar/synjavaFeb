import java.util.Date;

public class Lab1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("In Lab1 Main...");
		Date d1 = new Date();
	//	java.sql.Date d2 = new java.sql.Date(d1.getTime());
		System.out.println("d1 = " + d1);
	//	System.out.println("d2 = " + d2);
	}

}

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

public class Lab2 {

	public static void main(String[] args) {
		List<String> list = new ArrayList<>();
		list.add("a"); list.add("bb");list.add("ccc");list.add("dddd");
/*
 * 		Stream<String> str= list.stream().filter(x->x.length() >2);
 * 	str.forEach(System.out::println);
 */
		list.stream().filter(x->x.length() >2).forEach(System.out::println);
		
		Optional<String> optionalstring = list.stream().filter(x->x.length() >4).findFirst();
		if (optionalstring.isPresent())
				System.out.println("First Element - " + optionalstring.get());
		else
				System.out.println("No element found");
	}

}

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class Lab5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Emp> list = new ArrayList();
		String[] names = {"Vaishali","Suman","Salani","Vishal", "Simon" };
		for (int i = 1;i<=50;i++){
			Emp e = new Emp();
			e.setEmpno(i);
			
			e.setEname(names[(i % names.length) ]);
			//e.setSalary((int)(Math.random()*1000));
			e.setSalary(i*1000);
			list.add(e);
		}
	list.stream().skip(5).limit(10).forEach(System.out::println);
}
}
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

public class Lab7 {
// Reduce
	public static void main(String[] args) {
		Stream<Integer> strint = Stream.of(10,300,400,301,22,155);
		List<String> list = new ArrayList<>();
		list.add("a"); list.add("bb");list.add("ccc");list.add("ddd");
	
		Optional<Integer> opint = strint.reduce((a,b)->a+b);
		System.out.println("OpInt value = " + opint.get());
		Optional<String> opstr = list.stream().reduce((a,b)->a+b);
		System.out.println("OpString value = " + opstr.get());
		
		
}
}
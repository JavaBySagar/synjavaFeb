import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class Lab1 {

	public static void main(String[] args) {
		Stream<Integer> strint = Stream.of(10,300,400,301,22,155);
		strint.forEach(System.out::println);
		List<String> list = new ArrayList<>();
		list.add("a"); list.add("bb");list.add("ccc");list.add("ddd");
		
		Stream<String> strstr = list.stream();
		
		strstr.forEach(System.out::println);
		list.stream().forEach(System.out::println);
		list.stream().forEach(System.out::println);
	}

}

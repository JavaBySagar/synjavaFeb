import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class Lab3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Emp> list = new ArrayList();
		String[] names = {"Vaishali","Suman","Salani","Vishal", "Simon" };
		for (int i = 1;i<=10;i++){
			Emp e = new Emp();
			e.setEmpno(i);
			
			e.setEname(names[(i % names.length) ]);
			e.setSalary((int)(Math.random()*1000));
			list.add(e);
		}
		list.forEach(System.out::println);
		
		
		 // Filter all records where salary > somenumber
		System.out.println("All records where salary is greater than 400");
		list.stream().filter((e)->e.getSalary()>400).forEach(System.out::println);
		
		System.out.println("Show a record is empno is matching (Filter,Findfirst)");
		Optional<Emp> opemp = list.stream().filter((e)->e.getEmpno()==4).findFirst();
		System.out.println("Optional Emp " + opemp.get());
		 
		System.out.println("Show records where salary is between .. and ..");
		list.stream().filter((e)->e.getSalary()>200 && e.getSalary()<500).forEach(System.out::println);
		
		System.out.println("Show all employee where ename length is 5 characters");
		list.stream().filter((e)->e.getEname().length()==5).forEach(System.out::println);
	}
}

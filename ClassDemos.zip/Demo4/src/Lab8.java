import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Lab8 {
// Reduce
	public static void main(String[] args) {
		Stream<Integer> strint = Stream.of(104,300,400,300,104,155);
		List<String> list = new ArrayList<>();
		list.add("a"); list.add("bb");list.add("ccc");list.add("ddd");
	
		List<Integer> strlist = strint.distinct().collect(Collectors.toList());	
		System.out.println(strlist);
		
}
}
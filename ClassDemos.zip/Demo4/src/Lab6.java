import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class Lab6 {
// Map
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Emp> list = new ArrayList();
		String[] names = {"Vaishali","Suman","Salani","Vishal", "Simon" };
		for (int i = 1;i<=5;i++){
			Emp e = new Emp();
			e.setEmpno(i);
			e.setEname(names[(i % names.length) ]);
			e.setSalary((int)(Math.random()*1000));
			list.add(e);
		}
		System.out.println("Initial List");
		list.stream().forEach(System.out::println);
		System.out.println("After Map for int");
		list.stream().map((e)->e.getSalary()).forEach(System.out::println);
		System.out.println("\n\n"  + list.stream().mapToDouble(e->e.getSalary()).max().getAsDouble());
		
		
		
		
}
}
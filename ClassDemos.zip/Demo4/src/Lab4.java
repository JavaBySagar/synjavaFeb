import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class Lab4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Emp> list = new ArrayList();
		String[] names = {"Vaishali","Suman","Salani","Vishal", "Simon" };
		for (int i = 1;i<=5;i++){
			Emp e = new Emp();
			e.setEmpno(i);
			
			e.setEname(names[(i % names.length) ]);
			//e.setSalary((int)(Math.random()*1000));
			e.setSalary(i*1000);
			list.add(e);
		}
		list.forEach(System.out::println);
		System.out.println("before .........................");
//		list.stream().filter(x->x.getSalary()>2000).peek(x->System.out.println("peek after filter"+x.getSalary())).forEach(System.out::println);
		Optional<Emp> oemp = list.stream().peek(x->System.out.println("before filter"+x.getSalary())).filter(x->x.getSalary()>2000).peek(x->System.out.println("peek after filter"+x.getSalary())).findFirst();
		System.out.println(oemp.get());
}
}
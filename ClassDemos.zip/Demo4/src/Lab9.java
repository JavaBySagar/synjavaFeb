import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

public class Lab9 {

	public static void main(String[] args) {
		System.out.println("Enter a number to continue..");
		Scanner scanner = new Scanner(System.in);
		scanner.nextInt();
	
		
		// TODO Auto-generated method stub
		List<Emp> list = new ArrayList();
		String[] names = {"Vaishali","Suman","Salani","Vishal", "Simon" };
		for (int i = 1;i<=99999;i++){
			Emp e = new Emp();
			e.setEmpno(i);
			
			e.setEname(names[(i % names.length) ]);
			//e.setSalary((int)(Math.random()*1000));
			e.setSalary(i*1000);
			list.add(e);
		}
	//	list.stream().filter((e)->e.getEname().startsWith("V")).forEach( e-> System.out.print(e.getEmpno()+" - " +e.getEname() +","));
		list.parallelStream().filter((e)->e.getEname().startsWith("V")).forEach( e-> System.out.print(e.getEmpno()+" - " +e.getEname() +","));
}
}
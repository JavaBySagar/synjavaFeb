interface StaticDemoInterface{
	public void m1();
	public static void m2(){
		System.out.println("m2 static of StaticDemoInterface");
	}
	public void m3();
}

class StaticDemoImpl1 implements StaticDemoInterface{

	@Override
	public void m1() {
		System.out.println("StaticDemoImpl1- m1");
		
	}

	@Override
	public void m3() {
		// TODO Auto-generated method stub
	}
	
}
class StaticDemoImpl2 implements StaticDemoInterface{

	@Override
	public void m1() {
		System.out.println("StaticDemoImpl2- m1");
		
	}
	
	@Override
	public void m3() {
		// TODO Auto-generated method stub
	}
}
// abstract, default, static

public class StaticDemo {
	public static void main(String[] args) {
		StaticDemoInterface inte = new StaticDemoImpl1();
		inte.m1();
		StaticDemoInterface.m2();
		StaticDemoInterface inte1 = new StaticDemoImpl2();
	}
}

import java.util.Date;

public class Lab1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			System.out.println("..................Hello World................... ");
			Date d1 = new Date();
			}
	}


interface Lab4Support{
	public void m1();
	
}
public class Lab4 {

	public static void main(String[] args) {
		Lab4Support s1 = ()->System.out.println("ss");
	}

}

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Lab3 {

	public static void main(String[] args) {
		List<String> names = Stream.of("Simran", "Saloni", "Asha", "Vaishali", "Lili").collect(Collectors.toList());
		names.stream().sorted().forEach(System.out::println);
	}

}

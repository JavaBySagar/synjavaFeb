import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class EmpMgr {
	public static List<Emp> createemp() {
		List<Emp> list = new ArrayList<Emp>();
		List<String> names = Stream.of("Simran", "Saloni", "Asha", "Vaishali", "Lili").collect(Collectors.toList());
		List<String> departments = Stream.of("HR", "TRN", "TA", "FIN").collect(Collectors.toList());

		for (int i = 0; i < 10; i++) {
			Emp e1 = new Emp();
			e1.setEmpno(i + 1);
			e1.setEname(names.get(i % names.size()));
			e1.setDept(departments.get(i % departments.size()));
			e1.setSalary((int) (Math.random() * 1000));
			list.add(e1);
		}
		return list;
	}
}

public class Lab1 {

	public static void main(String[] args) {
		List<Emp> list = EmpMgr.createemp();
				
		  Stream<Emp> original = list.stream(); 
		  Stream<Emp> empstr = 	  original.filter((e)->e.getDept().equals("HR"));
		  empstr.forEach(System.out::println);
		  
		  double sumforhr = list.stream().filter((e)->e.getDept().equals("HR")).mapToDouble((e)->e.getSalary()).sum();
		  System.out.println("sumfor HR = " + sumforhr);
		  double sumforfin = list.stream().filter((e)->e.getDept().equals("FIN")).mapToDouble((e)->e.getSalary()).sum();
		  System.out.println("sumfor FIN = " + sumforfin);
	
		  // Compute sum of salaries by department
		    Map<String, Double> totalByDept
		         = list.stream()
		                    .collect(Collectors.groupingBy(Emp::getDept,
		                                                   Collectors.summingDouble(Emp::getSalary)));
		    System.out.println(totalByDept);
		    
		    System.out.println("\n\n");
	
		    Map<String, List<Emp>> byDept
	         = list.stream()
	                    .collect(Collectors.groupingBy(Emp::getDept));
		    
		    byDept.forEach((str,lst)->System.out.println(str +", " + lst));
	}

}

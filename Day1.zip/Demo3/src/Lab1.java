import java.util.function.BiFunction;
import java.util.function.BinaryOperator;
import java.util.function.UnaryOperator;

public class Lab1 {

	public static void main(String[] args) {
		UnaryOperator<Integer> sqr = (i)->i*i;
		System.out.println("SQR of 10 is " + sqr.apply(10));
		BinaryOperator<Integer> add = (i,j)->i+j;
		System.out.println("Add with 200 and 300 is" + add.apply(200, 300));
	/*	BiFunction<String,String,Double> div = (x,y)->{
			Double i = Double.parseDouble(x);
			int j = Integer.parseInt(y);
			return i/j;
		};
	*/
		BiFunction<String,String,Double> div = (x,y)-> Double.parseDouble(x)/ Integer.parseInt(y);
	
		System.out.println("Divide with String 10 and 5 is " + div.apply("10", "5"));
		//int bigger(int, int)
		BinaryOperator<Integer> findbig = (x,y)->{
			if (x >= y)
				return x;
			else
				return y;
		};
		System.out.println("FindBig with 10 and 33 - " + findbig.apply(10,33));
	
	}

}

interface CalcInterface {
	public int calc(int i, int j);
}
interface Conversion{
	public int convert(int i);
}

public class Calc {

	public static void main(String[] args) {
		int rate  =10;
		CalcInterface add = (i,j)->i+j; 
		Conversion dtoy = (i)->{
			int rate1 = 100;
			rate1 =rate1* 300 ;
			return i *rate;
		};
		
	}

}

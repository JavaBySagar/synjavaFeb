interface ProblemDemoInterface1{
	
	public  default void m2(){
		System.out.println("m2 as default");
	}
	
}
interface ProblemDemoInterface2{
	public  default void m2(){
		System.out.println("m2 as default");
	}
	
}
/*// Cant compile code because of duplicate m2 definitions
class ProblemDemoImpl implements ProblemDemoInterface1, ProblemDemoInterface2{

}*/

// overriding both definitions with single m2 
class ProblemDemoImpl implements ProblemDemoInterface1, ProblemDemoInterface2{
@Override
public void m2() {
	// TODO Auto-generated method stub
	ProblemDemoInterface1.super.m2();
}
}


// abstract, default, static

public class ProblemDemo {
	public static void main(String[] args) {
		ProblemDemoInterface1 inte = new ProblemDemoImpl();
				inte.m2();
		
	}
}

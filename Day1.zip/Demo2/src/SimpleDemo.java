interface SimpleDemoInterface{
	public void m1();
	public  default void m2(){
		System.out.println("m2 as default");
	}
	public void m3();
}

class SimpleDemoImpl1 implements SimpleDemoInterface{

	@Override
	public void m1() {
		System.out.println("SimpleDemoImpl1- m1");
		
	}

	@Override
	public void m3() {
		// TODO Auto-generated method stub
	}
	
}
class SimpleDemoImpl2 implements SimpleDemoInterface{

	@Override
	public void m1() {
		System.out.println("SimpleDemoImpl2- m1");
	}
	@Override
	public void m2() {
	System.out.println("SimpleDemoImpl2 - m2");
	}

	@Override
	public void m3() {
		// TODO Auto-generated method stub
	}
}
// abstract, default, static

public class SimpleDemo {
	public static void main(String[] args) {
		SimpleDemoInterface inte = new SimpleDemoImpl1();
		inte.m1();
		inte.m2();
		SimpleDemoInterface inte1 = new SimpleDemoImpl2();
		inte1.m1();
		inte1.m2();
	}
}
